package thememeteam.com.yummycrummyapp5;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Toast;

import thememeteam.com.yummycrummyapp5.R;


public class UserSettings extends ActionBarActivity implements View.OnClickListener {
    EditText restNameTxt, dishNameTxt, notesTxt, ratingTxt;
    RatingBar rating;
    Preference currentPreference;
    DatabaseHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_settings);

        restNameTxt = (EditText) findViewById(R.id.editRestName);
        dishNameTxt = (EditText) findViewById(R.id.editDishName);
        notesTxt = (EditText) findViewById(R.id.editNotes);
        rating = (RatingBar) findViewById(R.id.ratingBar);

        dbHandler = new DatabaseHandler(this, null, null, 1);
        currentPreference = dbHandler.getPreference(dbHandler.getMyProfile(),"",dbHandler.getMyPreference(),1);
       // Toast.makeText(getApplicationContext(), currentPreference.getPrefID() + " has been clicked!", Toast.LENGTH_SHORT).show();


        Button backButton;
        backButton = (Button) findViewById(R.id.btnBack);
        backButton.setOnClickListener(this);

        Button deleteButton;
        deleteButton = (Button) findViewById(R.id.btnDelete);
        deleteButton.setOnClickListener(this);

        restNameTxt.setText(currentPreference.getRestaurant());
        dishNameTxt.setText(currentPreference.getFoodItem());
        notesTxt.setText(currentPreference.getComments());

        final Button submitBtn = (Button) findViewById(R.id.submitChangesButton);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Preference preference = new Preference(currentPreference.getProfileID(),
                        currentPreference.getPrefID(),
                        String.valueOf(restNameTxt.getText()),
                        String.valueOf(dishNameTxt.getText()),
                        rating.getRating(),
                        String.valueOf(notesTxt.getText()));
                dbHandler.updatePreference(preference);
               // Toast.makeText(getApplicationContext(), dbHandler.getPreferenceCount() + " preferences in the database!", Toast.LENGTH_SHORT).show();
                // Toast.makeText(getApplicationContext(), String.valueOf(genderTxt.getText()) + " has been edited!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent("thememeteam.com.yummycrummyapp5.ViewEditProfile2"));
            }


        });
    }

    private void backButtonClick()
    {

        startActivity(new Intent("thememeteam.com.yummycrummyapp5.ViewEditProfile2"));
    }

    //This function works as long as you only delete the last profile in the database...
    //Otherwise it goes bananas
    private void deleteButtonClick() {
        int deletedPreferenceID = currentPreference.getPrefID();
        int currentProfileID = currentPreference.getProfileID();
        dbHandler.deletePreference(deletedPreferenceID);
       // Toast.makeText(getApplicationContext(), dbHandler.getPreferenceCount() + " preferences in the database!", Toast.LENGTH_SHORT).show();
        //reset profileNumber?
        Preference nextPreference;
        if (dbHandler.getPreferenceCount() != 0)
        {
            for (int i = deletedPreferenceID + 1; i < dbHandler.getPreferenceCount() + 1; i++) {
                nextPreference = dbHandler.getPreference(dbHandler.getMyProfile(), "", i, 2);
                if(nextPreference != null)
                    dbHandler.updatePreferenceID(nextPreference, i - 1);
            }
        }
        startActivity(new Intent("thememeteam.com.yummycrummyapp5.ViewEditProfile2"));

    }
    @Override
    public void onClick(View view)
    {
        switch(view.getId())
        {
            case R.id.btnBack:
                backButtonClick();
                break;
            case R.id.btnDelete:
                deleteButtonClick();
                break;
        }
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_user_settings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
