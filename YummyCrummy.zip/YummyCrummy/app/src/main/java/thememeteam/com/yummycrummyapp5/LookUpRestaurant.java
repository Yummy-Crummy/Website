package thememeteam.com.yummycrummyapp5;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;


public class LookUpRestaurant extends ActionBarActivity {
    List<Profile> ProfileList = new ArrayList<Profile>();
    ListView profileListView;
    EditText resName, dishName, notes;
    RatingBar ratingBar;
    DatabaseHandler dbHandler;
    Profile currentProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_look_up_restaurant);
        dbHandler = new DatabaseHandler(this,null,null,1);
        profileListView = (ListView) findViewById(R.id.listViewRest);

        resName = (EditText) findViewById(R.id.restaurantName);
        dishName = (EditText) findViewById(R.id.dish);
        notes = (EditText) findViewById(R.id.notesField);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        final Button cancelButton = (Button) findViewById(R.id.cancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent("thememeteam.com.yummycrummyapp5.HomeScreen"));
            }
        });

        if (dbHandler.getProfileCount() != 0)
            ProfileList.addAll(dbHandler.getCorrectProfiles(dbHandler.getMyAccount()));

      //  Toast.makeText(getApplicationContext(),dbHandler.getProfileCount()+ " profiles in the database",Toast.LENGTH_SHORT).show();
        populateList();

        final Button submitButton = (Button) findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(currentProfile == null)
                {
                    Toast.makeText(getApplicationContext(), "Please select a profile to add your review to.", Toast.LENGTH_SHORT).show();

                }
                else
                {
                    Preference preference = new Preference(currentProfile.getProfileID(),
                            dbHandler.getPreferenceCount(),
                            String.valueOf(resName.getText()),
                            String.valueOf(dishName.getText()),
                            ratingBar.getRating(),
                            String.valueOf(notes.getText()));
                    dbHandler.createPreferences(preference);
                    Toast.makeText(getApplicationContext(), String.valueOf(currentProfile.getName()) + " has added a review!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent("thememeteam.com.yummycrummyapp5.HomeScreen"));
                }
            }

        });//end setOnClickListener

        profileListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
                                               {
                                                   @Override
                                                   public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                                                   {
                                                       LinearLayout ll = (LinearLayout) view;
                                                       // TextView clickedView = (TextView) ll.findViewById(R.id.listView2);
                                                       currentProfile = ProfileList.get(position);
                                                       dbHandler.setMyProfile(currentProfile.getProfileID());
                                                      // Toast.makeText(LookUpRestaurant.this, "Item with username "+currentProfile.getName() + " profileID" + currentProfile.getProfileID(),Toast.LENGTH_SHORT).show();
                                                     //  startActivity(new Intent("thememeteam.com.yummycrummyapp5.ViewEditProfile2"));
                                                   }
                                               }
        );

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_look_up_restaurant, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private class ProfileListAdapter extends ArrayAdapter<Profile> {
        public ProfileListAdapter(){
            super (LookUpRestaurant.this, R.layout.profile_listview_item,ProfileList);
        }
        @Override
        public View getView(int position, View view, ViewGroup parent){
            if (view == null)
                view = getLayoutInflater(). inflate(R.layout.profile_listview_item,parent,false);
            Profile currentProfile = ProfileList.get(position);

            TextView name = (TextView) view.findViewById(R.id.addProfileName);
            name.setText(currentProfile.getName());

            TextView birthday = (TextView) view.findViewById(R.id.addProfileBirthday);
            birthday.setText(currentProfile.getBirthday());

            TextView gender = (TextView) view.findViewById(R.id.addProfileGender);
            gender.setText(currentProfile.getGender());

            return view;
        }

    }


    private void populateList(){
        ArrayAdapter<Profile> adapter = new ProfileListAdapter();
        profileListView.setAdapter(adapter);
    }
}
