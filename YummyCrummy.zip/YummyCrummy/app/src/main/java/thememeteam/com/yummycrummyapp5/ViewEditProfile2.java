package thememeteam.com.yummycrummyapp5;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

//dkjg
public class ViewEditProfile2 extends Activity implements View.OnClickListener {
    List<Preference> PreferenceList = new ArrayList<Preference>();
    ListView preferenceListView;
    EditText nameTxt, birthdayTxt, genderTxt;
    Profile currentProfile;
    DatabaseHandler dbHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_edit_profile2);


        nameTxt = (EditText) findViewById(R.id.editRestName);
        birthdayTxt = (EditText) findViewById(R.id.editDishName);
        genderTxt = (EditText) findViewById(R.id.editNotes);
        dbHandler = new DatabaseHandler(this, null, null, 1);
        currentProfile = dbHandler.getProfile(dbHandler.getMyAccount(),"",dbHandler.getMyProfile(),1);
        preferenceListView = (ListView) findViewById(R.id.listViewPref);

        Button backButton;
        backButton = (Button) findViewById(R.id.btnBack);
        backButton.setOnClickListener(this);

        Button deleteButton;
        deleteButton = (Button) findViewById(R.id.btnDelete);
        deleteButton.setOnClickListener(this);

        nameTxt.setText(currentProfile.getName());
        genderTxt.setText(currentProfile.getGender());
        birthdayTxt.setText(currentProfile.getBirthday());

        if (dbHandler.getPreferenceCount() != 0)
            PreferenceList.addAll(dbHandler.getCorrectPreferences(dbHandler.getMyProfile()));

       // Toast.makeText(getApplicationContext(),dbHandler.getProfileCount()+ " profiles in the database",Toast.LENGTH_SHORT).show();
        populatePreferenceList();



        final Button submitBtn = (Button) findViewById(R.id.submitChangesButton);
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Profile profile = new Profile(currentProfile.getAccountID(),
                        currentProfile.getProfileID(),
                        String.valueOf(nameTxt.getText()),
                        String.valueOf(birthdayTxt.getText()),
                        String.valueOf(genderTxt.getText()));
                dbHandler.updateProfile(profile);
               // Toast.makeText(getApplicationContext(), dbHandler.getProfileCount() + " profiles in the database!", Toast.LENGTH_SHORT).show();
                // Toast.makeText(getApplicationContext(), String.valueOf(genderTxt.getText()) + " has been edited!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent("thememeteam.com.yummycrummyapp5.ViewEditProfile"));
            }


        });

        preferenceListView.setOnItemClickListener(new AdapterView.OnItemClickListener()
                                               {
                                                   @Override
                                                   public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                                                   {
                                                       //LinearLayout ll = (LinearLayout) view;
                                                       // TextView clickedView = (TextView) ll.findViewById(R.id.listView2);
                                                       Preference currentPreference = PreferenceList.get(position);
                                                       dbHandler.setMyPreference(currentPreference.getPrefID());
                                                     //  Toast.makeText(ViewEditProfile2.this, "Item with username "+currentPreference.getRestaurant() + " profileID" + currentProfile.getProfileID(),Toast.LENGTH_SHORT).show();
                                                       startActivity(new Intent("thememeteam.com.yummycrummyapp5.UserSettings"));
                                                   }
                                               }
        );


    }

    private void backButtonClick()
    {

        startActivity(new Intent("thememeteam.com.yummycrummyapp5.ViewEditProfile"));
    }

    //This function works as long as you only delete the last profile in the database...
    //Otherwise it goes bananas
    private void deleteButtonClick() {
        int deletedProfileID = currentProfile.getProfileID();
        int currentAccountID = currentProfile.getAccountID();
        dbHandler.deleteProfile(deletedProfileID);
        dbHandler.deleteAllPreferences(deletedProfileID);
        Preference nextPreference;
        int count = dbHandler.getPreferenceCount();
        int newID = 0;
        if(dbHandler.getPreferenceCount() != 0)
        {
            for (int i = 0; i < count + 1; i++) {
                nextPreference = dbHandler.getPreference(dbHandler.getMyProfile(), "", i, 2);
                if (nextPreference != null)
                    dbHandler.updatePreferenceID(nextPreference, newID);
                    newID++;
            }
        }
      //  Toast.makeText(getApplicationContext(), dbHandler.getCurrentProfileCount(currentAccountID) + " profiles in the database!", Toast.LENGTH_SHORT).show();
        //reset profileNumber?
        Profile nextProfile;
        if (dbHandler.getProfileCount() != 0)
        {
            for (int i = deletedProfileID + 1; i < dbHandler.getProfileCount() + 1; i++) {
                nextProfile = dbHandler.getProfile(dbHandler.getMyAccount(), "", i, 2);
                if(nextProfile != null)
                    dbHandler.updateProfileID(nextProfile, i - 1);
            }
        }
        startActivity(new Intent("thememeteam.com.yummycrummyapp5.ViewEditProfile"));
    }

    @Override
    public void onClick(View view)
    {
        switch(view.getId())
        {
            case R.id.btnBack:
                backButtonClick();
                break;
            case R.id.btnDelete:
                deleteButtonClick();
                break;
        }
    }


    /**
     * A placeholder fragment containing a simple view.
     */
    private class PreferenceListAdapter extends ArrayAdapter<Preference> {
        public PreferenceListAdapter(){
            super (ViewEditProfile2.this, R.layout.preference_list_view,PreferenceList);
        }
        @Override
        public View getView(int position, View view, ViewGroup parent){
            if (view == null)
                view = getLayoutInflater(). inflate(R.layout.preference_list_view,parent,false);
            Preference currentPreference = PreferenceList.get(position);

            TextView restName = (TextView) view.findViewById(R.id.restField);
            restName.setText(currentPreference.getRestaurant());

            TextView dishName = (TextView) view.findViewById(R.id.dishField);
            dishName.setText(currentPreference.getFoodItem());

            TextView rating = (TextView) view.findViewById(R.id.ratingField);
            rating.setText(Float.toString(currentPreference.getRating()));

            TextView notes = (TextView) view.findViewById(R.id.notesField);
            notes.setText(currentPreference.getComments());

            return view;
        }

    }


    private void populatePreferenceList(){
        ArrayAdapter<Preference> adapter = new PreferenceListAdapter();
        preferenceListView.setAdapter(adapter);
    }

}
